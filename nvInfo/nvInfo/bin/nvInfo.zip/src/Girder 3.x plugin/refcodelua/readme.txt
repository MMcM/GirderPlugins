Girder Lua-Scripting development package.
-----------------------------------------

19 October 2002.

It's possible to augment Lua through Girder plugins, the Messagebox
directory contains an example of how this is done.

Requirements
Microsoft Visual C++ 6.0
Girder header file
Girder 3.2.6 pre 2 +

Make sure the include directory is in the searchpath for MSVC++.

Have fun.