This is for nvidia display adapters only

This is a commandline version of nvInfo.  The Visual Studio project you want to load to work on this project is in src\Commandline\NvCpl\nvcpltest.  The other project higher up is the original Nvidia one that is for .net or something...not used here.

-h for help.

This code is just provided as a starting point to those who find it useful. There is a lot of functionality one could add quite simply. I might add some more functionality as I need it.

This code is based in part on ref code from Promixis (sdks) and nVidia...ref code at(specifically NVIDIA Control Panel API sample): http://download.nvidia.com/developer/SDK/Individual_Samples/samples.html

Disclaimer: This software has no warranties expressed or implied.  Use at your own risk